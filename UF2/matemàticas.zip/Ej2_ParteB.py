from operaciones_matematicas import sumar, restar, multiplicar, dividir

print ('\nsumar =', sumar(num1, num2))
print ('restar =', restar(num1, num2))
print ('multiplicar =', multiplicar(num1, num2))
print ('dividir =', dividir(num1, num2))

#Finalmente para que funcione este último apartado debemos de importar el módulo de operacions_matematicas de la siguiente forma
#Realizamos un from operaciones_matematicas import sumar,restar,multiplicar,dividir de esta forma seleccionamos cada función que deseamos printar por pantalla
#Solamente tendremos que poner el nombre de las funciones que hayan dentro del módulo operaciones_matematicas sin necesidad de llamar a este módulo

print("")
autor = __author__ = "Alfonso Domínguez & Rayan Haizour"
copy = __copyright__="Copyright © 2023 Alfonso Domínguez & Ryan Haizour"

print(autor)
print(copy)