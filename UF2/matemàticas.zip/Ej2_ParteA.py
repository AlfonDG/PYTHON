import operaciones_matematicas as ob

print ('\nsumar =', ob.sumar(ob.num1,ob.num2))
print ('restar =', ob.restar(ob.num1,ob.num2))
print ('multiplicar =', ob.multiplicar(ob.num1,ob.num2))
print ('dividir =', ob.dividir(ob.num1,ob.num2))

#La respuesta a la segunda pregunta del ejercicio es: Importar el módulo operaciones_matematicas y llamarlo con el alias de ob
#De esta forma podemos llamar al módulo de operaciones_matematicas bajo el nombre de ob

print("")
autor = __author__ = "Alfonso Domínguez & Rayan Haizour"
copy = __copyright__="Copyright © 2023 Alfonso Domínguez & Ryan Haizour"

print(autor)
print(copy)