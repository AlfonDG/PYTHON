import operaciones_matematicas

print ('sumar =', operaciones_matematicas.sumar(operaciones_matematicas.num1,operaciones_matematicas.num2))
print ('restar =', operaciones_matematicas.restar(operaciones_matematicas.num1,operaciones_matematicas.num2))
print ('multiplicar =', operaciones_matematicas.multiplicar(operaciones_matematicas.num1,operaciones_matematicas.num2))
print ('dividir =', operaciones_matematicas.dividir(operaciones_matematicas.num1,operaciones_matematicas.num2))

#Para que funcione el ejercicio debemos de importar cada función dentro del módulo operaciones_matematicas

print("")
autor = __author__ = "Alfonso Domínguez & Rayan Haizour"
copy = __copyright__="Copyright © 2023 Alfonso Domínguez & Ryan Haizour"

print(autor)
print(copy)